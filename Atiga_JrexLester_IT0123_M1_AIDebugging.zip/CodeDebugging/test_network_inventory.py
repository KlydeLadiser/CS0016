"""Automated validation for the IT0123 Module 1 debugging activity.

Place this file beside network_inventory.py, then run:
    python -m unittest -v test_network_inventory.py
"""

import unittest

import network_inventory as target


class NetworkInventoryTests(unittest.TestCase):
    def test_count_online(self):
        self.assertEqual(target.count_online(target.DEVICES), 3)

    def test_average_online_latency(self):
        self.assertAlmostEqual(
            target.average_online_latency(target.DEVICES), 62.3333333333, places=2
        )

    def test_find_slow_devices(self):
        names = [device["name"] for device in target.find_slow_devices(target.DEVICES)]
        self.assertEqual(names, ["core-switch-1"])

    def test_classification(self):
        expected = ["HEALTHY", "SLOW", "OFFLINE", "HEALTHY", "OFFLINE"]
        actual = [target.classify_device(device) for device in target.DEVICES]
        self.assertEqual(actual, expected)

    def test_all_devices_appear_in_rendered_lines(self):
        rendered = "\n".join(target.render_device_lines(target.DEVICES))
        for device in target.DEVICES:
            self.assertIn(device["name"], rendered)
            self.assertIn(device["ip_address"], rendered)

    def test_complete_report(self):
        report = target.build_report(target.DEVICES)
        self.assertIn("Total devices: 5", report)
        self.assertIn("Online devices: 3", report)
        self.assertIn("Average online latency: 62.33 ms", report)
        self.assertIn("Slow online devices (> 100 ms): 1", report)
        self.assertEqual(report.count("\n- "), 5)


if __name__ == "__main__":
    unittest.main(verbosity=2)
